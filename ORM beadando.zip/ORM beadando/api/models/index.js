module.exports = (sequelize, DataTypes) => {
    const Játékos = require("./jatekos")(sequelize, DataTypes);
    const Csapat = require("./csapat")(sequelize, DataTypes);
    const Logó = require("./logo")(sequelize, DataTypes);
    const Szurkoló = require("./szurkolo")(sequelize, DataTypes);

    Csapat.hasMany(Játékos, {
        foreignKey: "csapatAzonosító",
    });



    Csapat.hasOne(Logó, {
        foreignKey: "csapatAzonosító",
    });


    Szurkoló.belongsToMany(Csapat, {
        foreignKey: "szurkoloSzigSzam",
        through: "Szurkol",
    });


    return { Játékos, Csapat, Logó, Szurkoló,  };
};
