const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Logó extends Model {}

    Logó.init(
        {
            figura: {
                type: DataTypes.STRING,
                primaryKey: true,
                allowNull: false,
            },
            foszin:{
                type: DataTypes.STRING,
                primaryKey: true,
                allowNull: false,
            },

            keszitoNeve:{
                type: DataTypes.STRING,
                allowNull: false,
            },
            elkeszulesDatum:{
                type: DataTypes.DATE,
                allowNull: false,
            }

            
            
        },
        {
            sequelize,
            modelName: "Logó",
            freezeTableName: true,
            timestamps: false,
        }
    );

    return Logó;
};
