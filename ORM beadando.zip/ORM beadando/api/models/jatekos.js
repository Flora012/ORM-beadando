const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
    class Játékos extends Model {}

    Játékos.init(
        {
            szigSzám: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
                allowNull: false,
            },
            gólszáma: {
                type: DataTypes.INTEGER,
            },
            név: {
                type: DataTypes.STRING(50),
            },
            nem: {
                type: DataTypes.ENUM("Férfi", "Nő"),
            },
            születésiDátum: {
                type: DataTypes.DATE,
            },
            magasság: {
                type: DataTypes.FLOAT,
            },
            súly: {
                type: DataTypes.FLOAT,
            },
            kor: {
                type: DataTypes.INTEGER,
            },
            igazolásIdeje: {
                type: DataTypes.DATE, // Új attribútum
            },
        },
        {
            sequelize,
            modelName: "Játékos",
            freezeTableName: true,
            timestamps: false,
        }
    );

    return Játékos;
};
